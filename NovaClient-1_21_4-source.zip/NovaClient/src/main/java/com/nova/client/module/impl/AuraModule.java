package com.nova.client.module.impl;

import com.nova.client.mixin.LivingEntityInvoker;
import com.nova.client.module.BooleanSetting;
import com.nova.client.module.Category;
import com.nova.client.module.ModeSetting;
import com.nova.client.module.Module;
import com.nova.client.module.NumberSetting;
import com.nova.client.rotation.RotationManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;

/** Combat module. Use only where this is permitted. */
public final class AuraModule extends Module {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    // Range: how far away a target can be locked. Reach: how far away it can be hit (max 6).
    public final NumberSetting range = new NumberSetting("Range", 6.0, 1.0, 10.0, 0.5);
    public final NumberSetting reach = new NumberSetting("Reach", 3.5, 1.0, 6.0, 0.1);
    public final ModeSetting rotationType = new ModeSetting("Rotation Type", "Matrix", "Matrix", "ReallyWorld", "Funtime Snap");
    public final ModeSetting lockMode = new ModeSetting("Lock Mode", "Focused", "Focused", "Free", "Legit", "Rage");
    public final BooleanSetting freeLook = new BooleanSetting("FreeLook", true);
    /** Focused / Legit / Rage: W walks towards the target even while you look somewhere else. */
    public final BooleanSetting moveToTarget = new BooleanSetting("Move To Target", true);
    public final BooleanSetting onlyCrit = new BooleanSetting("Only Crit", false);
    /** With Only Crit: jumps by itself when a hit is ready, so you never have to time the jump. */
    public final BooleanSetting autoJump = new BooleanSetting("Auto Jump (Crit)", true);
    public final BooleanSetting shieldBreaker = new BooleanSetting("Shield Breaker", true);

    private PlayerEntity target;
    private boolean snapLocked;
    private float wanderYaw, wanderPitch;

    public AuraModule() {
        super("Aura", "Combat module.", Category.COMBAT);
    }

    /** The player Aura is currently locked on, or null. */
    public PlayerEntity getTarget() { return target; }

    @Override public void onEnable() { release(); }
    @Override public void onDisable() { release(); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        target = pickTarget();
        if (target == null) { release(); return; }

        boolean inReach = distanceTo(target) <= reach.getValue();
        boolean ready = attackReady();
        float[] aim = rotationsTo(aimPoint(target));

        // Move fix: Focused / Legit / Rage walk towards the target with W, Free moves freely.
        if (lockMode.is("Free") || !moveToTarget.isEnabled()) RotationManager.clearMove();
        else RotationManager.setMove(bearingTo(target), lockMode.is("Rage"));

        // Only Crit + Auto Jump: leave the ground when a hit is ready and the target is in reach.
        if (onlyCrit.isEnabled() && autoJump.isEnabled() && inReach && mc.currentScreen == null
                && mc.player.isOnGround() && !mc.player.isTouchingWater() && !mc.player.isClimbing()
                && mc.player.getAttackCooldownProgress(0.5f) >= 0.85f) {
            ((LivingEntityInvoker) mc.player).nova$invokeJump();
        }

        if (rotationType.is("Funtime Snap")) {
            tickSnap(aim, inReach, ready);
        } else {
            tickLocked(aim, inReach, ready);
        }
    }

    // ---- Matrix (head) and ReallyWorld (between legs and torso): locked on the aim point ----
    private void tickLocked(float[] aim, boolean inReach, boolean ready) {
        float[] cur = currentRotation();

        // The server already has `cur` (it went out with this tick's movement packet).
        if (inReach && ready && isAimed(cur, aim) && legitGate()) doAttack();

        applyRotation(lockRotation(cur, aim));
    }

    // ---- Funtime Snap: look at the enemy only to hit, then look around randomly ----
    private void tickSnap(float[] aim, boolean inReach, boolean ready) {
        if (snapLocked) {
            // The snap rotation was sent this tick: hit, then look somewhere random again.
            if (inReach && ready) doAttack();
            snapLocked = false;
            randomizeWander();
            applyRotation(new float[]{wanderYaw, wanderPitch});
        } else if (inReach && ready) {
            // About to hit: lock on the enemy (sent with the next packet).
            float[] cur = currentRotation();
            float yaw = cur[0] + MathHelper.wrapDegrees(aim[0] - cur[0]);
            float pitch = MathHelper.clamp(aim[1], -90.0F, 90.0F);
            if (!lockMode.is("Rage")) {
                yaw = gcdFix(cur[0], yaw);
                pitch = MathHelper.clamp(gcdFix(cur[1], pitch), -90.0F, 90.0F);
            }
            applyRotation(new float[]{yaw, pitch});
            snapLocked = true;
        } else {
            // Waiting for the next hit: slowly drifting random look.
            ThreadLocalRandom rnd = ThreadLocalRandom.current();
            wanderYaw += (float) rnd.nextDouble(-4.0, 4.0);
            wanderPitch = MathHelper.clamp(wanderPitch + (float) rnd.nextDouble(-2.0, 2.0), -60.0F, 70.0F);
            applyRotation(new float[]{wanderYaw, wanderPitch});
        }
    }

    private void randomizeWander() {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        float[] cur = currentRotation();
        wanderYaw = cur[0] + (float) rnd.nextDouble(-160.0, 160.0);
        wanderPitch = (float) rnd.nextDouble(-30.0, 50.0);
    }

    // ---- Lock modes ----
    private float[] lockRotation(float[] cur, float[] aim) {
        float dyaw = MathHelper.wrapDegrees(aim[0] - cur[0]);
        float dpitch = aim[1] - cur[1];

        if (lockMode.is("Rage")) {
            // Full power, no protection: instant exact aim.
            return new float[]{cur[0] + dyaw, MathHelper.clamp(aim[1], -90.0F, 90.0F)};
        }
        if (lockMode.is("Legit")) {
            // Smooth, speed limited, a bit of noise so it does not look like a perfect lock.
            ThreadLocalRandom rnd = ThreadLocalRandom.current();
            float maxYaw = (float) rnd.nextDouble(16.0, 30.0);
            float maxPitch = (float) rnd.nextDouble(7.0, 14.0);
            float stepYaw = MathHelper.clamp(dyaw * (float) rnd.nextDouble(0.45, 0.8), -maxYaw, maxYaw);
            float stepPitch = MathHelper.clamp(dpitch * (float) rnd.nextDouble(0.45, 0.8), -maxPitch, maxPitch);
            float yaw = cur[0] + stepYaw + (float) rnd.nextDouble(-0.25, 0.25);
            float pitch = cur[1] + stepPitch + (float) rnd.nextDouble(-0.2, 0.2);
            return new float[]{gcdFix(cur[0], yaw), MathHelper.clamp(gcdFix(cur[1], pitch), -90.0F, 90.0F)};
        }
        // Focused / Free: instant lock, rounded to the mouse step like a real mouse.
        float yaw = gcdFix(cur[0], cur[0] + dyaw);
        float pitch = MathHelper.clamp(gcdFix(cur[1], aim[1]), -90.0F, 90.0F);
        return new float[]{yaw, pitch};
    }

    private boolean isAimed(float[] cur, float[] aim) {
        float tol = lockMode.is("Rage") ? 15.0F : (lockMode.is("Legit") ? 5.0F : 8.0F);
        return Math.abs(MathHelper.wrapDegrees(aim[0] - cur[0])) <= tol && Math.abs(aim[1] - cur[1]) <= tol;
    }

    /** Legit only: skips a few hits at random so the hit rhythm is not perfect. */
    private boolean legitGate() {
        return !lockMode.is("Legit") || ThreadLocalRandom.current().nextFloat() > 0.12F;
    }

    // ---- Rotation output: FreeLook = silent (camera stays free), otherwise the camera turns ----
    private float[] currentRotation() {
        if (freeLook.isEnabled() && RotationManager.isActive()) {
            return new float[]{RotationManager.getYaw(), RotationManager.getPitch()};
        }
        return new float[]{mc.player.getYaw(), mc.player.getPitch()};
    }

    private void applyRotation(float[] rot) {
        if (freeLook.isEnabled()) {
            RotationManager.set(rot[0], rot[1]);
        } else {
            RotationManager.clear();
            mc.player.setYaw(rot[0]);
            mc.player.setPitch(rot[1]);
        }
    }

    private void release() {
        RotationManager.clear();
        RotationManager.clearMove();
        snapLocked = false;
        target = null;
    }

    // ---- Attacking ----
    private boolean attackReady() {
        if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return false;
        if (!onlyCrit.isEnabled()) return true;
        // Only Crit: hit only while in the air and falling.
        return !mc.player.isOnGround() && (mc.player.fallDistance > 0.0f || mc.player.getVelocity().y < 0.0)
                && !mc.player.isClimbing() && !mc.player.isTouchingWater();
    }

    private void doAttack() {
        if (shieldBreaker.isEnabled() && target.isBlocking() && breakShield()) return;
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    /** Swaps to an axe, hits and swaps back inside the same tick. False if there is no axe. */
    private boolean breakShield() {
        var inv = mc.player.getInventory();
        int axe = -1;
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).getItem() instanceof AxeItem) { axe = i; break; }
        }
        if (axe == -1) return false;
        int original = inv.selectedSlot;
        inv.selectedSlot = axe;
        mc.interactionManager.attackEntity(mc.player, target); // syncs the slot to the server first
        mc.player.swingHand(Hand.MAIN_HAND);
        inv.selectedSlot = original;
        return true;
    }

    // ---- Targeting ----
    private PlayerEntity pickTarget() {
        // Focused / Legit / Rage stay on the same player until he dies or leaves Range.
        if (!lockMode.is("Free") && target != null && valid(target) && distanceTo(target) <= range.getValue()) {
            return target;
        }
        PlayerEntity best = null;
        double nearest = range.getValue();
        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof PlayerEntity player && valid(player)) {
                double d = distanceTo(player);
                if (d <= nearest) { nearest = d; best = player; }
            }
        }
        return best;
    }

    private boolean valid(PlayerEntity p) {
        return p != mc.player && p.isAlive() && !p.isSpectator();
    }

    /** Eye to closest point of the target's hitbox, like the server measures reach. */
    private double distanceTo(Entity e) {
        Vec3d eye = mc.player.getEyePos();
        Box b = e.getBoundingBox();
        double x = MathHelper.clamp(eye.x, b.minX, b.maxX);
        double y = MathHelper.clamp(eye.y, b.minY, b.maxY);
        double z = MathHelper.clamp(eye.z, b.minZ, b.maxZ);
        return eye.distanceTo(new Vec3d(x, y, z));
    }

    // ---- Aim math ----
    /** Matrix = head, ReallyWorld = between legs and torso, Funtime Snap = body center. */
    private Vec3d aimPoint(PlayerEntity e) {
        double y;
        if (rotationType.is("Matrix")) y = e.getEyeY();
        else if (rotationType.is("ReallyWorld")) y = e.getY() + e.getHeight() * 0.4;
        else y = e.getY() + e.getHeight() * 0.5;
        return new Vec3d(e.getX(), y, e.getZ());
    }

    private float[] rotationsTo(Vec3d point) {
        Vec3d eye = mc.player.getEyePos();
        double x = point.x - eye.x;
        double y = point.y - eye.y;
        double z = point.z - eye.z;
        double flat = Math.sqrt(x * x + z * z);
        float yaw = (float) (Math.atan2(z, x) * (180 / Math.PI)) - 90.0F;
        float pitch = (float) -(Math.atan2(y, flat) * (180 / Math.PI));
        return new float[]{yaw, MathHelper.clamp(pitch, -90.0F, 90.0F)};
    }

    private float bearingTo(Entity e) {
        double x = e.getX() - mc.player.getX();
        double z = e.getZ() - mc.player.getZ();
        return (float) (Math.atan2(z, x) * (180 / Math.PI)) - 90.0F;
    }

    /** Rounds a rotation change to the mouse-sensitivity step, like a real mouse would produce. */
    private float gcdFix(float previous, float wanted) {
        double sens = mc.options.getMouseSensitivity().getValue();
        double f = sens * 0.6 + 0.2;
        double step = f * f * f * 8.0 * 0.15;
        double delta = wanted - previous;
        return previous + (float) (Math.round(delta / step) * step);
    }
}
