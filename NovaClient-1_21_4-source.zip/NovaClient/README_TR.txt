NovaClient — Minecraft 1.21.4 / Fabric / Java 21

Bu kaynak projesi, sohbette paylaşılan sınıfları bir araya getirir ve eksik temel sınıfları ekler.

İçerik:
- Module / Category ve ayar sınıfları
- ModuleManager ve basit klavye kısayolu kontrolü
- 1.21.4 DrawContext tabanlı HUD çizimi
- fabric.mod.json ve Gradle yapılandırması
- AuraModule kaynak taslağı
- V (Velocity) ayar taslağı

Derleme:
1. Java 21 ve Gradle 8.x uyumlu bir ortam kullanın.
2. Bu klasörde `gradle build` çalıştırın (veya Gradle wrapper ekleyip `./gradlew build` kullanın).
3. Çıktı JAR'ı build/libs/ altında oluşmalıdır.

Dürüst durum notları:
- Bu ortamda Gradle derlemesi çalıştırılıp doğrulanmadı; API/mapping uyuşmazlığı çıkarsa hata mesajına göre düzeltme gerekebilir.
- V modülü ayar iskeletidir; gerçek velocity davranışı uygulanmamıştır.
- AuraModule otomatik hedef seçimi ve saldırı davranışı içerir; yalnızca tek oyunculu veya izin verilen test ortamlarında kullanın.
- Module key varsayılanı 0 olduğu için tuş atamaları varsayılan olarak kapalıdır; koddan setKey(...) ile atanabilir.
- HUD API'si 1.21.4 DrawContext kullanımına güncellendi.

ZalithLauncher / PojavLauncher (Android):
- Fabric 1.21.4 profili ve Java 21 kullan, jar'i mods klasorune Fabric API ile birlikte at.
- Menuyu acmak icin: duraklatma (ESC) menusundeki "NovaClient" butonu (klavye gerekmez),
  ya da kontrol duzenleyiciden bir butonu "NovaClient ClickGui" tusuna (varsayilan P) bagla.
- Dar ekranda paneller alt alta siralanir; bos yere surukleyerek kaydirabilirsin.
- Modulun ayarlarini acmak icin satirin sag taraftaki ok isaretine dokun.
- Ekranda cizim sorunu olursa launcher ayarindan baska bir renderer dene.
