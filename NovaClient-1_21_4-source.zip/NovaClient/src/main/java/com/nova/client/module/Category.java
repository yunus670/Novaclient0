package com.nova.client.module;

public enum Category {
    COMBAT("Combat"),
    MOVE("Move"),
    RENDER("Render"),
    PLAYER("Player"),
    MISC("Misc");

    private final String displayName;

    Category(String displayName) { this.displayName = displayName; }

    public String getDisplayName() { return displayName; }
}
