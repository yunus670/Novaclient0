package com.nova.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import org.joml.Matrix4f;

/**
 * Rounded rectangles and circles drawn as triangle fans with float coordinates, so edges are
 * smooth at the real screen resolution instead of chunky GUI-pixel steps.
 */
public final class Draw2D {
    private Draw2D() { }

    public static void roundedRect(DrawContext ctx, float x1, float y1, float x2, float y2, float radius, int color) {
        if (x2 <= x1 || y2 <= y1) return;
        float r = Math.max(0.0F, Math.min(radius, Math.min((x2 - x1) / 2.0F, (y2 - y1) / 2.0F)));
        int steps = r < 2.5F ? 3 : 9;

        ctx.draw(); // draw everything queued so far first, keeps the drawing order right
        Matrix4f m = ctx.getMatrices().peek().getPositionMatrix();
        BufferBuilder b = begin();
        vertex(b, m, (x1 + x2) / 2.0F, (y1 + y2) / 2.0F, color);
        corner(b, m, x2 - r, y1 + r, r, 270, steps, color); // top right
        corner(b, m, x2 - r, y2 - r, r, 0, steps, color);   // bottom right
        corner(b, m, x1 + r, y2 - r, r, 90, steps, color);  // bottom left
        corner(b, m, x1 + r, y1 + r, r, 180, steps, color); // top left
        corner(b, m, x2 - r, y1 + r, r, 270, 0, color);     // back to the start to close the fan
        end(b);
    }

    public static void circle(DrawContext ctx, float cx, float cy, float radius, int color) {
        ctx.draw();
        Matrix4f m = ctx.getMatrices().peek().getPositionMatrix();
        BufferBuilder b = begin();
        vertex(b, m, cx, cy, color);
        int segments = radius > 5.0F ? 48 : 32;
        for (int i = 0; i <= segments; i++) {
            double a = Math.PI * 2.0 * i / segments;
            vertex(b, m, cx + (float) Math.cos(a) * radius, cy + (float) Math.sin(a) * radius, color);
        }
        end(b);
    }

    private static void corner(BufferBuilder b, Matrix4f m, float cx, float cy, float r, int startDeg, int steps, int color) {
        if (steps == 0) {
            double a = Math.toRadians(startDeg);
            vertex(b, m, cx + (float) Math.cos(a) * r, cy + (float) Math.sin(a) * r, color);
            return;
        }
        for (int i = 0; i <= steps; i++) {
            double a = Math.toRadians(startDeg + 90.0 * i / steps);
            vertex(b, m, cx + (float) Math.cos(a) * r, cy + (float) Math.sin(a) * r, color);
        }
    }

    private static BufferBuilder begin() {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        return Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
    }

    private static void end(BufferBuilder b) {
        BuiltBuffer built = b.endNullable();
        if (built != null) BufferRenderer.drawWithGlobalProgram(built);
    }

    private static void vertex(BufferBuilder b, Matrix4f m, float x, float y, int color) {
        b.vertex(m, x, y, 0.0F).color((color >> 16) & 255, (color >> 8) & 255, color & 255, (color >> 24) & 255);
    }
}
