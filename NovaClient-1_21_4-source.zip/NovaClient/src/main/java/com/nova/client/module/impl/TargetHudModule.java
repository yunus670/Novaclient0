package com.nova.client.module.impl;

import com.nova.client.gui.Draw2D;
import com.nova.client.gui.Theme;
import com.nova.client.gui.UiFont;
import com.nova.client.module.Category;
import com.nova.client.module.Module;
import com.nova.client.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

import java.util.Locale;

/** Name and health of the player Aura is locked on, above the hotbar. */
public final class TargetHudModule extends Module {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private PlayerEntity lastTarget;
    private long lastSeen;
    private float shownRatio = 1.0F;

    public TargetHudModule() {
        super("TargetHUD", "Shows the Aura target's name and health.", Category.RENDER);
        setToggled(true);
    }

    @Override
    public void onRender2D(DrawContext ctx) {
        if (mc.player == null || mc.options == null || mc.options.hudHidden) return;

        AuraModule aura = ModuleManager.get(AuraModule.class);
        PlayerEntity current = (aura != null && aura.isToggled()) ? aura.getTarget() : null;
        long now = System.currentTimeMillis();
        if (current != null) {
            if (current != lastTarget) shownRatio = 1.0F;
            lastTarget = current;
            lastSeen = now;
        }
        if (lastTarget == null) return;

        // fades out for a moment after the target is gone
        float alpha = current != null ? 1.0F : 1.0F - (now - lastSeen) / 350.0F;
        if (alpha <= 0.0F) { lastTarget = null; return; }

        float health = Math.max(0.0F, lastTarget.getHealth() + lastTarget.getAbsorptionAmount());
        float max = Math.max(1.0F, lastTarget.getMaxHealth());
        float ratio = MathHelper.clamp(health / max, 0.0F, 1.0F);
        shownRatio += (ratio - shownRatio) * 0.12F;

        int w = 126, h = 36;
        int x = (ctx.getScaledWindowWidth() - w) / 2;
        int y = ctx.getScaledWindowHeight() - 98;

        rrect(ctx, x - 1, y - 1, x + w + 1, y + h + 1, withAlpha(Theme.rgb(), alpha, 0x60));
        rrect(ctx, x, y, x + w, y + h, withAlpha(0x121218, alpha, 0xE0));

        // avatar: first letter of the name on the theme color
        String name = lastTarget.getName().getString();
        Draw2D.roundedRect(ctx, x + 5, y + 5, x + 31, y + 31, 4.0F, withAlpha(Theme.rgb(), alpha, 0x70));
        String initial = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
        UiFont.drawCentered(ctx, initial, x + 18, y + 12, withAlpha(0xFFFFFF, alpha, 0xFF));

        String hp = (int) Math.ceil(health) + " HP";
        int hpWidth = UiFont.width(hp);
        UiFont.draw(ctx, UiFont.trim(name, w - 46 - hpWidth), x + 37, y + 6, withAlpha(0xFFFFFF, alpha, 0xFF));
        UiFont.drawRight(ctx, hp, x + w - 6, y + 6, withAlpha(0xC8C8D2, alpha, 0xFF));

        int bx1 = x + 37, bx2 = x + w - 6, by = y + 22;
        Draw2D.roundedRect(ctx, bx1, by, bx2, by + 6, 3.0F, withAlpha(0xFFFFFF, alpha, 0x30));
        int fill = bx1 + (int) ((bx2 - bx1) * shownRatio);
        int barColor = ratio < 0.3F ? 0xFF5555 : Theme.rgb();
        Draw2D.roundedRect(ctx, bx1, by, fill, by + 6, 3.0F, withAlpha(barColor, alpha, 0xFF));
    }

    private static int withAlpha(int rgb, float alpha, int baseAlpha) {
        return ((int) (baseAlpha * MathHelper.clamp(alpha, 0.0F, 1.0F)) << 24) | (rgb & 0xFFFFFF);
    }

    private static void rrect(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        Draw2D.roundedRect(ctx, x1, y1, x2, y2, 4.0F, color);
    }
}
